# SimpleBayesNet

[![Python application](https://github.com/axiom9/SimpleBayesNet/actions/workflows/python-app.yml/badge.svg)](https://github.com/axiom9/SimpleBayesNet/actions/workflows/python-app.yml)

Wrapper on top of Pomegranate https://pomegranate.readthedocs.io/en/latest/ specifically focusing on Bayesian Network functionality
